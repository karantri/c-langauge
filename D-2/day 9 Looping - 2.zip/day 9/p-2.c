#include<stdio.h>
main(){
    int i;
  scanf("%d",&i);
    do
    {
        printf("%d\n",i);
        i--;
    } while (i>=1);
    
}

// #include <stdio.h>
// int main() {
//     int i=1,a;
//     scanf("%d",&a); 
//   do {
//     printf("%d\n", i);
//     i--;
//   }while (a >= i);

// }