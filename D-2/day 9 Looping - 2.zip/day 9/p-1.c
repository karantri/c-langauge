#include<stdio.h>
main(){
    int i=1,a;
    scanf("%d",&a);
    do
    {
        printf("%d\n",i);
        i++;
    } while (i<=a);
}
  


  // Print numbers from 1 to 5

#include <stdio.h>
int main() {
  int i = 1;
    
  do {
    printf("%d\n", i);
    ++i;
  }while (i <= 10);

}
